// console.log("Hi")

// function abc(){
//     confirm("js file access")
// }


// "use strict"
// var a=10;
// console.log(a)

// console.log(a)
// var a=10;

// var x=10
// function abc(){
//     console.log(x)
//     var x=20;
// }
// abc();

// function abc(a,b,c){
//     console.log(a+b+c)
// }
// // abc()

// abc(10,20,30)


// carry function ?????????????

// function abc() {
//     return function () {
//         return function () {
//             console.log(a + b + c)
//         }
//     }
// }
// // abc(1)(2)(3);


// Type of

// console.log(typeof null)     //o.t=object

// console.log(typeof 10)     //o.t=num

// console.log(typeof true)    //o.t=bolean

// console.log(typeof typeof null)

// console.log(typeof typeof 10)

// console.log(typeof typeof bamglore)   o.t=string



// Loops

// for(i=0; i<=10; i++){
//     console.log(i)
// }


// odd  numbers

// for (i = 1; i <= 10; i+=2) {
//     console.log(i)
// }


// even numbers

// for  (i=0; i<=10; i+=2){
//     console.log(i)
// }

// var str = "banglore is big city";

// var res = str.split("").reverse("").join();

// console.log(res);

// var str="banglore is big city"
// var res=str.split("").reverse("").join("").split(" ").reverse("").join(" ")
// console.log(res);


// Array: it will use two methodes
// remove duplicate elements

// var arr=[1,2,4,5,3,6,3,2,7,9,2];

// // var  res=[...new Set(arr)];
// // console.log(res);

// var uniqueeArr =[]
// function removeDuplicate(arr){
//     for(var value of arr){
//         if(uniqueeArr.indexOf(value)===-1){
//             uniqueeArr.push(value)
//         }
//     }
// }
// removeDuplicate(arr)
// console.log(auniqueeArr)


var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 7, 5, 2]

// var res=arr.sort();
// console.log(arr)

for (var i = 0; i < arr.length; i++) {
    for (var j = 1 + i; j < arr.length[j]; j++) {
        var temp = arr[i] < arr[i]
        var [i] = arr[j]
        arr[j] = temp
    }
}
console.log(arr)

